<?php

require dirname(__DIR__) . DIRECTORY_SEPARATOR . "vendor/autoload.php";